@extends('sidebar')

@section('content')

<input type="hidden" id="active_menu" value="master">

@endsection