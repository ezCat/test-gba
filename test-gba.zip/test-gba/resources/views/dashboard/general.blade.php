@extends('sidebar')

@section('content')

<input type="hidden" id="active_menu" value="general">

<div  class="col-sm-12">
<h3>Tableau de bord : Toutes Affaires</h3>
<hr/>
</div>

<div class="row">

	<div class="col-sm-5">

		<h3>Informations générales sur la base projet</h3>

		<br>

		<h4>Nombre de projet : <b>14</b></h4>

		<br>

		<h4>Heures prévues totales : <b>16150h</b></h4>

		<h4>Heures réalisées totales: <b>12544h</b></h4>

		<br>

		<h4>Total des commandes prévues: <b>1212000 €</b></h4>

		<h4>Total des commandes réalisées : <b>1145000 €</b></h4>

	</div>
	<div class="col-sm-7">
		<div class="row" style="margin-top: 10px">
			
			<a href=""><div class="col-md-6 col-sm-12 col-xs-12">
                <div class="panel back-dash purple">
                       <i class="fa fa-file-text-o fa-3x"></i><strong> &nbsp; LISTE AFFAIRE</strong>
                     <p class="text-muted">Cliquez ici pour ouvrir la liste des projets en cours ou soldés. Cette liste reprend plusieurs informations générales sur les différents projets.</p>
                </div>
            </div></a>

			<a href=""><div class="col-md-6 col-sm-12 col-xs-12">
                <div class="panel back-dash purple-light">
                       <i class="fa fa-bar-chart fa-3x"></i><strong> &nbsp; ETAT GLOBAL</strong>
                     <p class="text-muted">Cliquez ici pour ouvrir l'état global concernant l'ensemble des projets existants. Cet état reprend les budgets commandes et horaires. </p>
                </div>
            </div></a>

		</div>

		<div class="row">

			<a href=""><div class="col-md-6 col-sm-12 col-xs-12">
                <div class="panel back-dash purple-light">
                       <i class="fa fa-euro fa-3x"></i><strong> &nbsp; BILAN COMMANDES</strong>
                     <p class="text-muted">Cliquez ici pour ouvrir le bilan général concernant les commandes affectées aux fournisseurs. Les filtres peuvent vous guider.</p>
                </div>
            </div></a>

			<a href=""><div class="col-md-6 col-sm-12 col-xs-12">
                <div class="panel back-dash purple">
                       <i class="fa fa-clock-o fa-3x"></i><strong> &nbsp; BILAN HEURES</strong>
                     <p class="text-muted">Cliquez ici pour ouvrir le bilan général concernant les heures affectées aux ressources internes. Les filtres peuvent vous guider.</p>
                </div>
            </div></a>

		</div>
	</div>
</div>

@endsection