<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/simple-sidebar.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
  	<script src="<?php echo e(asset('js/tinymce/tinymce.min.js')); ?>"></script>
  	<script>tinymce.init({ selector:'textarea' });</script>
</head>

<?php echo $__env->yieldContent('navigation'); ?>

<?php echo $__env->yieldContent('content'); ?>
