<?php $__env->startSection('content'); ?>

<input type="hidden" id="active_menu" value="unique">

<div  class="col-sm-12">
<h3>Tableau de bord : LHP N4</h3>
<hr/>
</div>

<div class="row">

	<div class="col-sm-5">

		<h3>Informations générales sur le projet</h3>

		<br>

		<h4>Nom du projet : <b>LHP N4</b></h4>

		<br>

		<h4>Heures prévues : <b>160h</b></h4>

		<h4>Heures réalisées : <b>124h</b></h4>

		<br>

		<h4>Montant des commandes prévues : <b>12000 €</b></h4>

		<h4>Montant des commandes réalisées : <b>11000 €</b></h4>

	</div>
	<div class="col-sm-7">
		<div class="row" style="margin-top: 10px">
			
			<a href=""><div class="col-md-6 col-sm-12 col-xs-12">
                <div class="panel back-dash purple">
                       <i class="fa fa-file-text-o fa-3x"></i><strong> &nbsp; LISTE AFFAIRE</strong>
                     <p class="text-muted">Cliquez ici pour ouvrir la liste des projets en cours ou soldés. Cette liste reprend plusieurs informations générales sur les différents projets.</p>
                </div>
            </div></a>

			<a href=""><div class="col-md-6 col-sm-12 col-xs-12">
                <div class="panel back-dash purple-light">
                       <i class="fa fa-bar-chart fa-3x"></i><strong> &nbsp; ETAT GLOBAL</strong>
                     <p class="text-muted">Cliquez ici pour ouvrir l'état global concernant l'ensemble des projets existants. Cet état reprend les budgets commandes et horaires. </p>
                </div>
            </div></a>

		</div>

		<div class="row">

			<a href=""><div class="col-md-6 col-sm-12 col-xs-12">
                <div class="panel back-dash purple-light">
                       <i class="fa fa-euro fa-3x"></i><strong> &nbsp; BILAN COMMANDES</strong>
                     <p class="text-muted">Cliquez ici pour ouvrir le bilan général concernant les commandes affectées aux fournisseurs. Les filtres peuvent vous guider.</p>
                </div>
            </div></a>

			<a href=""><div class="col-md-6 col-sm-12 col-xs-12">
                <div class="panel back-dash purple">
                       <i class="fa fa-clock-o fa-3x"></i><strong> &nbsp; BILAN HEURES</strong>
                     <p class="text-muted">Cliquez ici pour ouvrir le bilan général concernant les heures affectées aux ressources internes. Les filtres peuvent vous guider.</p>
                </div>
            </div></a>

		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>