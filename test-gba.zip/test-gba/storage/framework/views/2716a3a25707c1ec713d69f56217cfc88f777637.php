<head>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.9.1/themes/start/jquery-ui.css">
    <script src="//code.jquery.com/jquery-1.10.2.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
</head>

<?php $__env->startSection('content'); ?>

    <h1>Retours Bêta-testeurs</h1>
    <br>

    <?php echo Form::open(['url' => route('contact.store')]); ?>


   
    <?php echo Form::label('description', 'Remarques/Observations : '); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?><br>
    <?php echo Form::hidden('gid', $_SERVER['AUTH_USER'], ['class' => 'form-control']); ?>


    <?php echo Form::submit('Envoyer', ['class' => 'btn btn-primary']); ?>

      

    <br><br><br>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>