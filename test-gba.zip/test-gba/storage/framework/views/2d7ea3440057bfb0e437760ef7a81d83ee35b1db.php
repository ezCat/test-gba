<?php $__env->startSection('content'); ?>

<h4>Derniers documents éditer</h4>

<ul>
    <?php foreach($documents as $document): ?>
    <li><a href="<?php echo e(route('dop.show', $document->id)); ?>">
            DOP Ouvrier : Ouverte par <?php echo e($document->nom); ?> <?php echo e($document->prenom); ?> le <?php echo e($document->date_demande); ?>

        </a>
    </li>
    <?php endforeach; ?>
</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>