    
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="" style="padding-top: 20px;">Cellule Projet</a> 
            </div>
			  <div style="color: white;padding: 10px 50px 5px 50px;float: right;font-size: 16px;"> 
			  Dernière connexion : 30 Mai 2014 &nbsp; <a href="#" class="btn btn-danger square-btn-adjust">Déconnexion</a> </div>
        </nav>   


        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="<?php echo e(asset('img/suez.png')); ?>" class="user-image img-responsive"/>
					</li>
                    <li>
                        <a href="" id="ajouter"><i class="fa fa-folder-open fa-3x"></i> Ajouter une affaire</a>
                    </li>	
                    <li>
                        <a href="/public/ajouter/affaire" id="saisie"><i class="fa fa-pencil-square-o fa-3x"></i> Saisie d'une affaire</a>
                    </li>	
                    <li>
                        <a></a>
                    </li>
                    <li>
                        <a href="/public/dashboard/general" id="general"><i class="fa fa-money fa-3x"></i> Bilan : Général</a>
                    </li>	
                    <li>
                        <a href="/public/dashboard/unique" id="unique"><i class="fa fa-line-chart fa-3x"></i> Bilan : Affaire Unique</a>
                    </li>				
                    <li>
                        <a href="/public/dashboard/master" id="master"><i class="fa fa-tasks fa-3x"></i> Tableau de bord</a>
                    </li>	
                    <li>
                        <a></a>
                    </li>
                    <li>
                        <a href=""><i class="fa fa-cogs fa-3x"></i> Besoin d'aide ?</a>
                    </li>
                </ul>
            </div>
        </nav>  

		<div id="page-wrapper" >
		<div id="page-inner">
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>