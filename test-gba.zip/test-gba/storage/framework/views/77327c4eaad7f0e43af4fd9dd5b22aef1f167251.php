<?php $__env->startSection('content'); ?>

<h4>Derniers documents édités</h4>

<ul>
    <?php /*<?php foreach($documents as $document): ?>*/ ?>
    <?php /*<li><a href="<?php echo e(route('dop.show', $document->id)); ?>">*/ ?>
            <?php /*DOP Ouvrier : Ouverte par <?php echo e($document->nom); ?> <?php echo e($document->prenom); ?> le <?php echo e($document->date_demande); ?>*/ ?>
        <?php /*</a>*/ ?>
    <?php /*</li>*/ ?>
    <?php /*<?php endforeach; ?>*/ ?>
</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>