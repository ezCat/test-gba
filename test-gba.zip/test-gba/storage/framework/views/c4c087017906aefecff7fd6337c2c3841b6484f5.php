<?php $__env->startSection('content'); ?>

<input type="hidden" id="active_menu" value="master">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>