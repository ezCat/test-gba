$( document ).ready(function() {
  $("#btn-ensemble").animatedModal({
  		modalTarget: 'modal-ensemble',
        animatedIn:'zoomIn',
        animatedOut:'zoomOut',
        color:'#1b1b1b'
  });
	$("#btn-heure").animatedModal({
		modalTarget: 'modal-heure',
        animatedIn:'zoomIn',
        animatedOut:'zoomOut',
        color:'#1b1b1b'
  });
	$("#btn-commande").animatedModal({
  		modalTarget: 'modal-commande',
        animatedIn:'zoomIn',
        animatedOut:'zoomOut',
        color:'#1b1b1b'
  });
	$("#btn-ressource").animatedModal({
  		modalTarget: 'modal-ressource',
        animatedIn:'zoomIn',
        animatedOut:'zoomOut',
        color:'#1b1b1b'
  });
	$("#btn-fournisseur").animatedModal({
  		modalTarget: 'modal-fournisseur',
        animatedIn:'zoomIn',
        animatedOut:'zoomOut',
        color:'#1b1b1b'
  });
});