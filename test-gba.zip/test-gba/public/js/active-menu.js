$( document ).ready(function() {
	var toActive = $('#active_menu').val();
	$('#'+toActive).addClass('active-menu');
});